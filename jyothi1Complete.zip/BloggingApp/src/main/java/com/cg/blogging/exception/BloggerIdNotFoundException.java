package com.cg.blogging.exception;

public class BloggerIdNotFoundException extends Exception
{
	public BloggerIdNotFoundException(String msg)
	{
		super(msg);
	}

}