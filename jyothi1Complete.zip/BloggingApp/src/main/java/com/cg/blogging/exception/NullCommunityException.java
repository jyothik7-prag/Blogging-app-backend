package com.cg.blogging.exception;

public class NullCommunityException extends Exception{
	public NullCommunityException(String msg) {
		super(msg);
	}

}
