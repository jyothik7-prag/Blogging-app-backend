package com.cg.blogging.exception;

public class NullBloggerException extends Exception
{
	public NullBloggerException(String msg) 
	{
		super(msg);
	}
}