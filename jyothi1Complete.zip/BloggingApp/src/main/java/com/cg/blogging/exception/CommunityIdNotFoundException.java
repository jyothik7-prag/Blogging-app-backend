package com.cg.blogging.exception;

public class CommunityIdNotFoundException extends Exception{
	public CommunityIdNotFoundException(String msg) {
		super(msg);
	}
}
